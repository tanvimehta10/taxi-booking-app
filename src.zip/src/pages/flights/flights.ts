import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-fliights',
  templateUrl: 'flights.html'
})
export class FlightsPage {

  constructor(public navCtrl: NavController) {

  }

}
